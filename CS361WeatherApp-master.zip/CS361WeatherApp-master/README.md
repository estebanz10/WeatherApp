Ideas for app
- make an app
- 
