package weather;

import java.util.ArrayList;

public class Hazards {
    public ArrayList<Values> values;
}
