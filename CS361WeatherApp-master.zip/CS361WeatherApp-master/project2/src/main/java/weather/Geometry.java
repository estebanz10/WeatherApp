package weather;

import java.util.ArrayList;

public class Geometry{
    public String type;
    public ArrayList<ArrayList<ArrayList<Double>>> coordinates;
}
