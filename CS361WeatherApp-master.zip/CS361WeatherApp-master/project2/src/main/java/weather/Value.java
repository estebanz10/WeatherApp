package weather;

public class Value {
    public String phenomenon;
    public String significance;
    public int event_number;
}
